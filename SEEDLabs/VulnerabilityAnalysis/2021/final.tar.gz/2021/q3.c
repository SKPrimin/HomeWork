/* sudo sysctl -w kernel.randomize_va_space=0 then ... */
/*User Return-to-libc to execute 
system("/usr/bin/id");
setreuid(0,0);
system("id");
execl("/bin/sh","sh",NULL);
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int bof(FILE *badfile)
{
     long i=0x23456789;

    char buffer[97];
    /* The following statement has a buffer overflow problem */
    fread(buffer, sizeof(char), 430, badfile);
    if(i != 0x23456789) {
        printf(" Warnning: Buffer Overflow !!! \n");
     kill(0,11);
    }


    return 1;
}

int main(int argc, char **argv)
{
    FILE *badfile;
    badfile = fopen("badfile", "r");
    bof(badfile);
    printf("Returned Properly\n");
    fclose(badfile);
    return 1;
}

