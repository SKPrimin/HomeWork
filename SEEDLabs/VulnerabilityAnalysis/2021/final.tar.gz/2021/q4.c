#include <stdlib.h>
#define A(x) atoi(a[x])
#define S sizeof(int)
int main(int c,char**a){
      int*p=malloc(A(1)*S);
      if(A(2)<=A(1)*S)
              p[A(2)]=A(3);
      free(p);
      return (0);
}

