#include <stdio.h>
#include <stdlib.h>
extern char **environ;
vul(int argc, char *argv[])
{
        char buffer[40];
        int i;
        if(argc < 2){
                printf("argv error\n");
                exit(0);
        }

        for(i=0; environ[i]; i++)
                memset(environ[i], 0, strlen(environ[i]));

        if(argv[1][47] != '\xbf')
        {
                printf("stack is still your friend.\n");
                exit(0);
        }
        strcpy(buffer, argv[1]);
        printf("%s\n", buffer);
        // buffer hunter
        memset(buffer, 0, 40);
}
main(int argc, char *argv[])
{
	vul(argc,argv);
}
