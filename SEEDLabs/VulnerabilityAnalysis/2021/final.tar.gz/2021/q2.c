#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <err.h>

unsigned short secret = 0x234;

void handle_fail(char *buf) {
  char msg[100];
  snprintf(msg, sizeof(msg), "Invalid Passwd! %s\n", buf);
  printf(msg);
}

int main(int argc, char *argv[])
{
  
  int tmp = secret;

  char buf[100];
  printf("Password:");
  strncpy(buf,argv[1],99);

  if (!strcmp(buf, "63582")) {
    printf("Pass OK :)\n");
  } else {
    handle_fail(buf);
  }

  if (tmp != secret) {
    puts("Secret modified!\n");
    exit(1);
  }
  
  return 0;
}

