
This is a shared folder between the host machine
and the container. It is created for the convenience
of the lab.
